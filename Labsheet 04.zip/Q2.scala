import scala.concurrent.duration.Duration.Zero

object Q2 {

    def calculate (integer: Int) : Unit= {

        if(integer <= 0)
        {
          println("Zero or negetive")
        }
        else if(integer % 2 == 0)
        {
          println("Even number")
        }
        else
        {
          println("Odd number")
        }
    }

    def main (args : Array [String]) : Unit = {
      val integer = 53
      val p= calculate(integer)
    }

}
